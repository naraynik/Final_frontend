# AuthentiQ frontend

Website for AuthentiQ, a product authentication system: a landing page, a customer "Scan a product" page and a manufacturer page.

**Backend developers: start with [HANDOFF.md](HANDOFF.md).** It explains how to run this, where the sample data lives and which API calls each page needs.

```sh
bun install
bun run dev
```

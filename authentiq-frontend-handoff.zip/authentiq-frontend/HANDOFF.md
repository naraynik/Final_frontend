# AuthentiQ frontend: handoff for backend integration

This is the AuthentiQ website frontend: the landing page, the customer **Scan a product** page and the **Manufacturer** page (register, verification pending, add products).
It looks and behaves like the finished design, but **all data is fake**: nothing is sent to the FastAPI backend or the blockchain yet.
Your job is to swap the fake data for real API calls.

There is no admin portal in this frontend, by design. Manufacturer approval happens in the separate admin dashboard.

---

## 1. Run it

Needs Node 18+ and [Bun](https://bun.sh) (`npm` had trouble with this project's lock file).

```sh
bun install
bun run dev        # dev server; open the address it prints
bun run build      # production build (output in .output/)
bun run test       # 2 smoke tests
```

The `preview/` folder holds the finished design as single HTML files you can double-click, if you only want to see how it should look:

- `authentiq.html`: the main version (navy and gold)
- `authentiq-navy-gold.html` and `authentiq-black-lime.html`: the two colour schemes the team is choosing between

To rebuild that single-file version after changes: `python3 scripts/build-single-html.py` (writes `dist-single/authentiq.html`).

---

## 2. Stack, and how it differs from the main repo

- **TanStack Start + Vite + React 19 + Tailwind CSS v4**, TypeScript, with three.js for the globe and jsQR for camera QR scanning.
- **Not Next.js.** The main repo's README says the frontend is Next.js 16. You have two options:
  1. Run this project as the frontend as it is (simplest).
  2. Move it into the Next.js app. Everything in `src/components`, `src/lib`, `src/assets` and `src/styles.css` is plain React + Tailwind and copies over. Only the page switching in `src/routes/index.tsx` (the `App` function at the bottom) needs replacing with Next.js routes.
- **Page switching uses the URL hash**, so the site also works as a single file opened from disk: `#/` is the landing page, `#/scan` the scan page, `#/manufacturer` the manufacturer page.

## 3. Where things live

| File | What it is |
|---|---|
| `src/routes/index.tsx` | Landing page (all sections) + the `App` page switcher at the bottom |
| `src/components/ScanPage.tsx` | Customer page: scan QR / enter product ID, scan report, raise an issue, sample reports |
| `src/components/ManufacturerPage.tsx` | Manufacturer page: register / log in, verification pending, product registration form |
| `src/components/GlobeDemo.tsx` | The 3D globe demo on the landing page (marketing only, no backend needed) |
| `src/components/Shell.tsx` | Logo, header and footer for the inner pages, shared button and card styles |
| **`src/lib/demoStore.ts`** | **All fake data and every "backend" call. Start here.** |
| `src/styles.css` | Colour tokens and animations |

---

## 4. What to connect

Everything the pages "send" or "fetch" goes through the functions in **`src/lib/demoStore.ts`**.
Replace each one with a real API call (they will need to become `async` and the call sites need `await` plus a loading state).
The `Product` type at the top of that file is the shape the pages expect to get back.

### Customer side (`ScanPage.tsx`)

| Frontend function | Called when | Should call | Notes |
|---|---|---|---|
| `scanProduct(code, place)` | Customer scans a QR code or types a product ID | `GET /api/verify/{qr_code}` then `POST /api/scans` | Must return a `Product` with its `scans` history and any `anomalies`, or `null` if the code is not on the blockchain. `place` is currently the text `"lat, lon"` or `"Location not shared"`; send real latitude/longitude numbers instead (see `shareLocation` in `ScanPage.tsx`). Scan history may come from `GET /api/scans/history/{product_id}`. |
| `raiseIssue(code, text)` | Customer presses "Raise an issue" on a report and sends the form | **No endpoint yet.** Needs e.g. `POST /api/issues` | Sends the product code and the customer's message. |
| `peekProduct(code)` | "View a sample report" (True product / False product) | **Keep local.** | These two sample reports should stay as built-in demo data. |

What the scan report shows, so the API needs to return it: product name, product code, batch, manufacturer, registered distributor and its address, blockchain block number, transaction hash, the list of scans (time and place, with suspicious ones flagged), and the AI anomaly reasons as plain sentences.

### Manufacturer side (`ManufacturerPage.tsx`)

| Step | Currently | Should call | Notes |
|---|---|---|---|
| **Register** | Goes straight to "Verification pending" | `POST /api/auth/manufacturer/register` (multipart) | Fields: `company`, `gstin` (validated as a 15-character GSTIN), `email`, `password`, `aadhaar` (PDF or image file). **The current backend expects a PDF document, not GSTIN + Aadhaar.** It needs these fields added. |
| **Log in** | Accepts anything and opens the dashboard as a sample company | `POST /api/auth/login` | Store the JWT and send it on manufacturer requests. If the account is not approved yet, show the "Verification pending" screen instead of the dashboard. |
| **Verification** | Pending screen has a demo-only **"Continue as verified"** button | Status comes from the backend; approval is done in the admin portal (`PUT /api/admin/manufacturers/{id}/status`) | **Remove the "Continue as verified" button.** |
| **Add products** (`submit` in the `Dashboard` component) | Calls `registerProduct()` once per product | `POST /api/products/register` | See below. |
| **Your registered products** list | `listProducts(company)` | **No endpoint yet.** Needs e.g. `GET /api/products` for the logged-in manufacturer | |

The **product registration form** collects more than the current API takes:

- **Company details:** company name, GST number, contact email.
- **Distributor locations:** a list. Each has name, street address, city, country and optional coordinates.
- **Facility location:** street address, city, country, coordinates (with a "Use my current location" button).
- **Products:** a list. Each has name, SKU, batch / serial.

Right now the form flattens the distributor list into one text string per product (`distributor` and `distributorAddress`) only because the fake store is simple. With a real API, send the structured lists instead. The state is already structured in the component (`distributors`, `facility`, `items`, `details`).
The backend needs fields for distributors and facility, because the AI uses the registered distributor address to raise "distributor does not match" anomalies.

## 5. Things to remove or change once it is live

- The **"This page runs on sample data…"** notes (`SampleNote` in `Shell.tsx`, used on both inner pages).
- The **"Continue as verified"** button on the pending screen.
- The fake login (any email and password currently works).
- The sample products and their codes in `demoStore.ts` (keep two of them for the sample reports, or move those into `ScanPage.tsx`).

## 6. Practical notes

- **API address:** put the backend URL in an env variable (for example `VITE_API_URL=http://127.0.0.1:8000`) rather than hard-coding it.
- **CORS:** the FastAPI backend must allow the frontend's address (`CORSMiddleware`). If the single-file HTML is opened from disk, the browser's origin is `null`.
- **Camera and location:** browsers only allow these on `https://` or `localhost`. They will not work on a plain `http://` address on another machine.
- **Error box:** in the single-file build, any JavaScript error is shown in a red-bordered box at the bottom of the page instead of a blank screen (`scripts/single-entry.tsx`). Useful while integrating.
- **Newer Chrome gotcha:** `window.scrollTo()` now returns a Promise in recent Chrome. Never `return` it from a React `useEffect`, or the page crashes to a blank screen. This already bit us once.
- **Media:** the hero video and photos load from Pexels and Unsplash (free licences). For a real launch, download them into the project instead of linking.
- **Colour scheme:** this source is the navy and gold version. If the team picks black and lime, only colour values change (`src/styles.css` tokens, a few hard-coded hex values in `src/routes/index.tsx`, `Shell.tsx`, `ScanPage.tsx`, `ManufacturerPage.tsx`, and the `--globe-*` values). Ask Narayani for the lime values.

## Team

Frontend: Narayani Khaparde (npkhaparde370223@kkwagh.edu.in). Team contacts are also in the site footer.

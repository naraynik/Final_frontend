/**
 * In-memory sample data for the scan and manufacturer pages.
 * Replace the functions at the bottom with calls to the FastAPI backend
 * (GET /api/verify/{qr_code}, POST /api/scans, POST /api/products/register).
 */

export type Scan = { time: string; place: string; flagged?: boolean };

export type Product = {
  code: string;
  name: string;
  batch: string;
  sku?: string;
  facility?: string;
  manufacturer: string;
  distributor: string;
  distributorAddress: string;
  txHash: string;
  block: number;
  scans: Scan[];
  anomalies: string[];
};

const hex = (n: number) =>
  Array.from({ length: n }, () => Math.floor(Math.random() * 16).toString(16)).join("");

const products: Product[] = [
  {
    code: "AQ-1001",
    name: "Herbal Green Tea 100 g",
    batch: "B-0427",
    manufacturer: "Sahyadri Foods (sample)",
    distributor: "Godavari Traders",
    distributorAddress: "College Road, Nashik",
    txHash: "0x8f3a1c97d2b44e0a6c1f5b7e9a3d2c4b8e6f0a1d",
    block: 1042,
    scans: [
      { time: "28 Sep, 16:05", place: "Nashik" },
      { time: "30 Sep, 11:20", place: "Nashik" },
    ],
    anomalies: [],
  },
  {
    code: "AQ-2002",
    name: "Vitamin C Tablets, 30 pack",
    batch: "B-0913",
    manufacturer: "Sahyadri Foods (sample)",
    distributor: "Western Medico",
    distributorAddress: "Andheri East, Mumbai",
    txHash: "0x2b7e44a09c1d3f5e8a6b0c2d4e6f8a1b3c5d7e9f",
    block: 1187,
    scans: [
      { time: "Today, 10:42", place: "Mumbai" },
      { time: "Today, 10:42", place: "London", flagged: true },
    ],
    anomalies: ["Scanned in 2 different locations at the same time (Mumbai and London)."],
  },
  {
    code: "AQ-3003",
    name: "Engine Oil Filter",
    batch: "B-2210",
    manufacturer: "Deccan Auto Parts (sample)",
    distributor: "Shivneri Motors",
    distributorAddress: "Hadapsar, Pune",
    txHash: "0x5d1c9e3b7a2f4c6e8b0d1f3a5c7e9b2d4f6a8c0e",
    block: 1320,
    scans: [{ time: "Yesterday, 18:30", place: "Delhi", flagged: true }],
    anomalies: ["Scan location (Delhi) does not match the registered distributor (Pune)."],
  },
];

/** The two sample reports offered on the scan page. */
export const SAMPLE_REPORTS = { genuine: "AQ-1001", fake: "AQ-2002" } as const;

/** Look a product up without recording a scan (used for sample reports). */
export function peekProduct(code: string): Product | null {
  return products.find((p) => p.code === code) ?? null;
}

const now = () =>
  new Date().toLocaleString("en-GB", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });

/** Look a product up by the code in its QR and record this scan. */
export function scanProduct(rawCode: string, place: string): Product | null {
  const code = rawCode.trim().toUpperCase();
  const product = products.find((p) => p.code === code);
  if (!product) return null;
  product.scans.push({ time: now(), place });
  return product;
}

export function listProducts(manufacturer: string): Product[] {
  return products.filter((p) => p.manufacturer === manufacturer);
}

export function registerProduct(
  input: Pick<
    Product,
    "name" | "batch" | "sku" | "facility" | "manufacturer" | "distributor" | "distributorAddress"
  >,
): Product {
  const product: Product = {
    ...input,
    code: `AQ-${4000 + products.length + 1}`,
    txHash: `0x${hex(40)}`,
    block: 1320 + products.length * 7,
    scans: [],
    anomalies: [],
  };
  products.push(product);
  return product;
}

const issues: { code: string; text: string }[] = [];
export function raiseIssue(code: string, text: string) {
  issues.push({ code, text });
}

import { useState, type FormEvent, type ReactNode } from "react";
import { Blocks, Building2, Clock, FileText, MapPin, Package, Plus, Truck, X } from "lucide-react";
import { listProducts, registerProduct, type Product } from "@/lib/demoStore";
import { card, field, pill, pillGhost, SampleNote } from "@/components/Shell";

type Stage = "register" | "login" | "pending" | "dashboard";

const label = "grid gap-1.5 text-sm font-semibold";

const STEPS = ["GST ID and Aadhaar", "Manual verification", "Add products"];

/** Three-step progress strip: submit documents, get verified, add products. */
function Steps({ current }: { current: number }) {
  return (
    <ol className="mt-8 grid grid-cols-3 gap-2 text-center text-xs font-semibold sm:text-sm">
      {STEPS.map((s, i) => (
        <li
          key={s}
          aria-current={i === current ? "step" : undefined}
          className={`rounded-2xl px-2 py-3 ${
            i < current
              ? "bg-genuine-soft text-genuine"
              : i === current
                ? "bg-brand text-white"
                : "bg-secondary text-subtle"
          }`}
        >
          <span className="block font-mono text-[11px] opacity-80">STEP {i + 1}</span>
          {s}
        </li>
      ))}
    </ol>
  );
}

function Auth({
  stage,
  setStage,
  setCompany,
}: {
  stage: Stage;
  setStage: (s: Stage) => void;
  setCompany: (c: string) => void;
}) {
  const [file, setFile] = useState("");
  const isRegister = stage === "register";

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    if (isRegister) {
      setCompany(String(data.get("company")));
      setStage("pending");
    } else {
      setCompany("Sahyadri Foods (sample)");
      setStage("dashboard");
    }
  };

  return (
    <div className="mx-auto max-w-[560px]">
      <div className="text-center">
        <h1 className="text-4xl font-extrabold sm:text-5xl">For manufacturers</h1>
        <p className="mx-auto mt-4 max-w-md text-lg">
          Store your products on the AuthentiQ blockchain so customers can check them.
        </p>
      </div>

      <Steps current={0} />

      <div className={`${card} mt-6`}>
        <div role="tablist" className="grid grid-cols-2 rounded-full bg-brand-soft p-1">
          {(["register", "login"] as const).map((s) => (
            <button
              key={s}
              type="button"
              role="tab"
              aria-selected={stage === s}
              onClick={() => setStage(s)}
              className={`rounded-full py-2.5 text-sm font-semibold transition-colors ${
                stage === s ? "bg-brand text-white" : "text-ink hover:text-brand"
              }`}
            >
              {s === "register" ? "Register" : "Log in"}
            </button>
          ))}
        </div>

        <form onSubmit={submit} className="mt-7 grid gap-4">
          {isRegister && (
            <>
              <label className={label}>
                Company name
                <input name="company" required className={field} autoComplete="organization" />
              </label>
              <label className={label}>
                GST ID (GSTIN)
                <input
                  name="gstin"
                  required
                  maxLength={15}
                  pattern="[0-9]{2}[A-Za-z]{5}[0-9]{4}[A-Za-z][A-Za-z0-9][Zz][A-Za-z0-9]"
                  title="15 characters, for example 27ABCDE1234F1Z5"
                  placeholder="27ABCDE1234F1Z5"
                  className={`${field} font-mono uppercase placeholder:normal-case`}
                  autoComplete="off"
                />
                <span className="font-normal text-subtle">
                  15 characters, as on your GST certificate.
                </span>
              </label>
            </>
          )}
          <label className={label}>
            Work email
            <input name="email" type="email" required className={field} autoComplete="email" />
          </label>
          <label className={label}>
            Password
            <input
              name="password"
              type="password"
              required
              minLength={8}
              className={field}
              autoComplete={isRegister ? "new-password" : "current-password"}
            />
          </label>
          {isRegister && (
            <label className={label}>
              Aadhaar card (PDF or photo)
              <span className="flex cursor-pointer items-center gap-3 rounded-xl border border-dashed border-brand/60 bg-brand-soft px-4 py-4 font-normal">
                <FileText className="size-6 flex-none text-brand" aria-hidden="true" />
                <span>{file || "Choose a file. Our team checks it by hand before approval."}</span>
                <input
                  type="file"
                  name="aadhaar"
                  accept="application/pdf,image/*"
                  required
                  className="sr-only"
                  onChange={(e) => setFile(e.target.files?.[0]?.name ?? "")}
                />
              </span>
            </label>
          )}
          <button type="submit" className={`${pill} mt-2`}>
            {isRegister ? "Submit for verification" : "Log in"}
          </button>
        </form>
      </div>
      <SampleNote />
    </div>
  );
}

type Distributor = { name: string; street: string; city: string; country: string; coords: string };
type Item = { name: string; sku: string; batch: string };

const emptyDistributor: Distributor = { name: "", street: "", city: "", country: "", coords: "" };
const emptyItem: Item = { name: "", sku: "", batch: "" };

function Section({
  icon: Icon,
  title,
  hint,
  children,
}: {
  icon: typeof Blocks;
  title: string;
  hint: string;
  children: ReactNode;
}) {
  return (
    <section className={card}>
      <div className="flex items-center gap-4">
        <span className="flex size-12 flex-none items-center justify-center rounded-2xl bg-brand-soft text-brand">
          <Icon className="size-6" strokeWidth={1.6} aria-hidden="true" />
        </span>
        <div>
          <h2 className="text-xl font-bold">{title}</h2>
          <p className="text-sm text-subtle">{hint}</p>
        </div>
      </div>
      <div className="mt-6">{children}</div>
    </section>
  );
}

/** Labelled text input bound to one key of a small form object. */
function Field<T extends Record<string, string>>({
  text,
  k,
  value,
  set,
  placeholder,
  wide,
}: {
  text: string;
  k: keyof T & string;
  value: T;
  set: (v: T) => void;
  placeholder: string;
  wide?: boolean;
}) {
  return (
    <label className={`${label} ${wide ? "sm:col-span-2" : ""}`}>
      {text}
      <input
        value={value[k]}
        onChange={(e) => set({ ...value, [k]: e.target.value })}
        placeholder={placeholder}
        className={field}
      />
    </label>
  );
}

const grid = "grid gap-4 sm:grid-cols-2";
const addBtn =
  "mt-5 inline-flex items-center gap-2 rounded-full border-2 border-brand bg-surface px-5 py-2.5 text-sm font-semibold text-brand transition-colors hover:bg-brand hover:text-white";
const chip = "flex items-center justify-between gap-3 rounded-xl bg-secondary px-4 py-3 text-sm";

function Dashboard({ company, onLogout }: { company: string; onLogout: () => void }) {
  const [details, setDetails] = useState({ company, gst: "", email: "" });
  const [facility, setFacility] = useState({ street: "", city: "", country: "", coords: "" });
  const [dist, setDist] = useState(emptyDistributor);
  const [distributors, setDistributors] = useState<Distributor[]>([]);
  const [item, setItem] = useState(emptyItem);
  const [items, setItems] = useState<Item[]>([]);
  const [error, setError] = useState("");
  const [stored, setStored] = useState<Product[]>([]);
  const [products, setProducts] = useState<Product[]>(() => listProducts(company));
  const [open, setOpen] = useState<string | null>(null);

  const addDistributor = () => {
    if (!dist.name.trim() || !dist.city.trim())
      return setError("Enter at least the distributor name and city, then add the distributor.");
    setDistributors([...distributors, dist]);
    setDist(emptyDistributor);
    setError("");
  };
  const addItem = () => {
    if (!item.name.trim() || !item.batch.trim())
      return setError("Enter at least the product name and batch / serial, then add the product.");
    setItems([...items, item]);
    setItem(emptyItem);
    setError("");
  };
  const useLocation = () =>
    navigator.geolocation?.getCurrentPosition(
      (p) =>
        setFacility((f) => ({
          ...f,
          coords: `${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`,
        })),
      () => setError("Could not read your location. Type the coordinates instead."),
    );

  const submit = (e: FormEvent) => {
    e.preventDefault();
    if (!items.length || !distributors.length)
      return setError("Add at least one distributor and one product before you submit.");
    const place = (d: { street: string; city: string; country: string }) =>
      [d.street, d.city, d.country].filter(Boolean).join(", ");
    const made = items.map((it) =>
      registerProduct({
        manufacturer: company,
        name: it.name,
        batch: it.batch,
        sku: it.sku,
        facility: place(facility),
        distributor: distributors.map((d) => d.name).join(", "),
        distributorAddress: distributors.map(place).join(" · "),
      }),
    );
    setStored(made);
    setItems([]);
    setDistributors([]);
    setError("");
    setProducts(listProducts(company));
  };

  return (
    <div className="mx-auto max-w-[860px]">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-xs tracking-widest text-genuine">VERIFIED MANUFACTURER</p>
          <h1 className="mt-1 text-3xl font-extrabold sm:text-4xl">Register your products</h1>
          <p className="mt-2 max-w-xl">
            Add your company, distributor locations, facility and products. They are stored on the
            AuthentiQ blockchain.
          </p>
        </div>
        <button type="button" className={pillGhost} onClick={onLogout}>
          Log out
        </button>
      </div>

      <form onSubmit={submit} className="mt-8 grid gap-5" noValidate>
        <Section
          icon={Building2}
          title="Company details"
          hint="As registered with the tax authority."
        >
          <div className={grid}>
            <Field
              text="Company name"
              k="company"
              value={details}
              set={setDetails}
              placeholder="Acme Electronics Pvt Ltd"
            />
            <Field
              text="GST number"
              k="gst"
              value={details}
              set={setDetails}
              placeholder="27AAECA1234F1Z5"
            />
            <Field
              text="Contact email"
              k="email"
              value={details}
              set={setDetails}
              placeholder="trust@acme.co"
            />
          </div>
        </Section>

        <Section
          icon={Truck}
          title="Distributor locations"
          hint="Add each distributor stop on a product's journey."
        >
          {distributors.length > 0 && (
            <ul className="mb-5 grid gap-2">
              {distributors.map((d, i) => (
                <li key={i} className={chip}>
                  <span>
                    <strong>{d.name}</strong> ·{" "}
                    {[d.street, d.city, d.country].filter(Boolean).join(", ")}
                  </span>
                  <button
                    type="button"
                    aria-label={`Remove ${d.name}`}
                    onClick={() => setDistributors(distributors.filter((_, j) => j !== i))}
                    className="text-subtle hover:text-fake"
                  >
                    <X className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
          <div className={grid}>
            <Field
              text="Distributor name"
              k="name"
              value={dist}
              set={setDist}
              placeholder="Northstar Distribution"
            />
            <Field
              text="Street address"
              k="street"
              value={dist}
              set={setDist}
              placeholder="Warehouse 8, Logistics Park"
            />
            <Field text="City" k="city" value={dist} set={setDist} placeholder="Dubai" />
            <Field
              text="Country"
              k="country"
              value={dist}
              set={setDist}
              placeholder="United Arab Emirates"
            />
            <Field
              text="Coordinates (optional)"
              k="coords"
              value={dist}
              set={setDist}
              placeholder="25.2048, 55.2708"
            />
          </div>
          <button type="button" className={addBtn} onClick={addDistributor}>
            <Plus className="size-4" aria-hidden="true" />
            Add distributor
          </button>
        </Section>

        <Section
          icon={MapPin}
          title="Facility location"
          hint="Where these products are manufactured."
        >
          <div className={grid}>
            <Field
              wide
              text="Street address"
              k="street"
              value={facility}
              set={setFacility}
              placeholder="Plot 14, MIDC Industrial Area"
            />
            <Field text="City" k="city" value={facility} set={setFacility} placeholder="Mumbai" />
            <Field
              text="Country"
              k="country"
              value={facility}
              set={setFacility}
              placeholder="India"
            />
            <Field
              text="Coordinates"
              k="coords"
              value={facility}
              set={setFacility}
              placeholder="19.0760, 72.8777"
            />
          </div>
          <button type="button" className={addBtn} onClick={useLocation}>
            <MapPin className="size-4" aria-hidden="true" />
            Use my current location
          </button>
        </Section>

        <Section icon={Package} title="Products" hint="Each product gets its own AuthentiQ code.">
          {items.length > 0 && (
            <ul className="mb-5 grid gap-2">
              {items.map((it, i) => (
                <li key={i} className={chip}>
                  <span>
                    <strong>{it.name}</strong> · {[it.sku, it.batch].filter(Boolean).join(" · ")}
                  </span>
                  <button
                    type="button"
                    aria-label={`Remove ${it.name}`}
                    onClick={() => setItems(items.filter((_, j) => j !== i))}
                    className="text-subtle hover:text-fake"
                  >
                    <X className="size-4" />
                  </button>
                </li>
              ))}
            </ul>
          )}
          <div className={grid}>
            <Field
              text="Product name"
              k="name"
              value={item}
              set={setItem}
              placeholder="Premium Wireless Headphones"
            />
            <Field text="SKU" k="sku" value={item} set={setItem} placeholder="ACM-HP-220" />
            <Field
              text="Batch / serial"
              k="batch"
              value={item}
              set={setItem}
              placeholder="B-2026-09"
            />
          </div>
          <button type="button" className={addBtn} onClick={addItem}>
            <Plus className="size-4" aria-hidden="true" />
            Add product
          </button>
        </Section>

        {error && (
          <p role="alert" className="rounded-xl bg-fake-soft p-4 text-sm font-semibold text-fake">
            {error}
          </p>
        )}
        <div className="flex flex-wrap items-center gap-4">
          <button type="submit" className={pill}>
            Submit registration
          </button>
          <span className="text-sm text-subtle">
            {items.length} {items.length === 1 ? "product" : "products"} · {distributors.length}{" "}
            {distributors.length === 1 ? "distributor" : "distributors"} added
          </span>
        </div>
        {stored.length > 0 && (
          <div role="status" className="rounded-2xl bg-genuine-soft p-5 text-genuine">
            <p className="font-bold">Stored on the blockchain:</p>
            <ul className="mt-2 space-y-1 text-sm">
              {stored.map((p) => (
                <li key={p.code}>
                  {p.name} · code <span className="font-mono font-semibold">{p.code}</span> · block{" "}
                  {p.block}
                </li>
              ))}
            </ul>
          </div>
        )}
      </form>

      {products.length > 0 && (
        <div className={`${card} mt-8`}>
          <h2 className="flex items-center gap-2 text-xl font-bold">
            <Blocks className="size-6 text-brand" aria-hidden="true" />
            Your registered products
          </h2>
          <ul className="mt-4 divide-y divide-line">
            {products.map((p) => (
              <li key={p.code} className="py-4">
                <button
                  type="button"
                  aria-expanded={open === p.code}
                  onClick={() => setOpen(open === p.code ? null : p.code)}
                  className="flex w-full flex-wrap items-center justify-between gap-3 text-left"
                >
                  <span>
                    <span className="block font-bold">{p.name}</span>
                    <span className="text-sm text-subtle">
                      <span className="font-mono">{p.code}</span> · Batch {p.batch} ·{" "}
                      {p.distributor}
                    </span>
                  </span>
                  {p.anomalies.length > 0 && (
                    <span className="rounded-full bg-fake-soft px-3 py-1 text-sm font-semibold text-fake">
                      Anomaly
                    </span>
                  )}
                </button>
                {open === p.code && (
                  <div className="mt-4 rounded-2xl bg-secondary p-4 text-sm">
                    <p className="font-mono break-all text-subtle">
                      Block {p.block} · {p.txHash}
                    </p>
                    <p className="mt-2">Distributor address: {p.distributorAddress}</p>
                    {p.facility && <p className="mt-1">Facility: {p.facility}</p>}
                    {p.anomalies.map((a) => (
                      <p
                        key={a}
                        className="mt-3 rounded-lg bg-fake-soft p-3 font-semibold text-fake"
                      >
                        {a}
                      </p>
                    ))}
                  </div>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
      <SampleNote />
    </div>
  );
}

export default function ManufacturerPage() {
  const [stage, setStage] = useState<Stage>("register");
  const [company, setCompany] = useState("");

  return (
    <div className="px-5 pt-32 pb-24">
      {stage === "dashboard" ? (
        <Dashboard company={company} onLogout={() => setStage("login")} />
      ) : stage === "pending" ? (
        <div className="mx-auto max-w-[560px]">
          <Steps current={1} />
          <div className={`${card} mt-6 text-center`}>
            <Clock className="mx-auto size-12 text-brand" strokeWidth={1.3} aria-hidden="true" />
            <h1 className="mt-4 text-3xl font-extrabold">Verification pending</h1>
            <p className="mx-auto mt-3 max-w-md">
              Thank you, {company}. Our team is checking your GST ID and Aadhaar card by hand. You
              can add products once your account is verified.
            </p>
            <p className="mx-auto mt-6 max-w-md rounded-xl bg-secondary p-4 text-sm text-subtle">
              Demo only: there is no admin portal in this preview, so use the button below to see
              what a verified manufacturer gets.
            </p>
            <button type="button" className={`${pill} mt-4`} onClick={() => setStage("dashboard")}>
              Continue as verified
            </button>
          </div>
        </div>
      ) : (
        <Auth stage={stage} setStage={setStage} setCompany={setCompany} />
      )}
    </div>
  );
}
